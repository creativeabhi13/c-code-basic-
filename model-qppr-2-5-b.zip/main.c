/**********************************************************************************
 model qppr-2 5-b
 Write an algorithm and develop a C program that reads N integer
numbers and arrange them in ascending order using selection Sort. 
 *********************************************************************************/ 
 #include<stdio.h>
 int main()
 {
 int array[100],i,j,n,min,temp;
 printf("enter the n element \n");
 scanf("%d",&n);
 printf("enter the integer %d\n",n);
    for(i=0;i<n;i++){
     scanf("%d",&array[i]);
    }
            for(i=0;i<n-1;i++)
              {
                  min=i;
                 for(j=i+1;j<n;j++)
                  {
                      if(array[j]<array[min])
                      min=j;
                  }
                     if(min != i)        
                         {
                             temp=array[i];
                             array[i]=array[min];
                             array[min]=temp;
                         }
                   
                 
              }
                                   printf("sorted list is in ascending order\n");
                                    for(i=0;i<n;i++)
                                     printf("%d\n",array[i]);
}                                     
                                     