/******************************************************************************
                structure program 3
*******************************************************************************/
#include <stdio.h>
struct std_record
        {
            int weight;
            float height;
          }student1 = {60,180.565};
      
int main()
{
   
 struct std_record student2 = {65, 170};
 printf("student1.weight student1.height\n");
 printf("%d\t\t%f",student1.weight,student1.height);
 printf("\nstudent2.weight student2.height\n");
 printf("%d\t\t%f",student2.weight,student2.height);
 
}   
   
   
   
   
   
   

