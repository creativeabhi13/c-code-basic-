#include<stdio.h>
int min()
{
    int a[50],key,first,last,mid,i,n;
    printf("enter the number of elements\n");
    scanf("%d",&n);
    printf("enter the %d elements of array\n",n);
        for(i=0;i<n,i++)
    scanf("%d",&a[i]);
    printf("enter the search key\n");
    scanf("%d",&key);
    first=0;
    last=n-1;
        while(first<=last)
            mid=(first+last)/2;
        if(a[mid]<key) {
            first=mid+1;
    }
        else if(a[mid]==key) {
    printf("key is found at location:%d",mid+1);
    break;
    }             
        else{
            last=mid-1;
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
