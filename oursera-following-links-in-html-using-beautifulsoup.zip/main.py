import urllib.request,urllib.parse,urllib.error
from bs4 import Beautifulsoup
import ssl 
import urllib

ctx=ssl.create_defualt_context()
ctx.check_hostname=False
ctx.verify_mode=ssl.CERT_NONE

link=input("enter url:")
count=int(input("enter counts"))
pos=int(input("enter lines"))
print("Retriving",link)
for i inrange(0,count):
    html=urllib.request.urlopen(link).read()
    soup=Beautifulsoup(html)
    tags=soup('a')
    
    link=tags[pos-1].get('href')
    
    result=tags[pos-1].contents[0]
    print("result")