/********************************************************************************
 model qppr-q 6-b
 
 Write a ‘C’ Program to read N numbers into an array & perform Linear search 8M 

 C program to input N numbers and store them in an array.
 Do a linear search for a given key and report success
 or failure.
 ********************************************************************************/ 
#include<stdio.h>
int main()
{
    int num;
    int i,keynum,found=0;
    printf("enter the number of elements in an array\n");
    scanf("%d",&num);
    int array[num];
    printf("enter thr kay element one by one\n");
                        for(i=0;i<num;i++)
                        {
                           scanf("%d",&array[i]);
                        }
                        
                          printf("enter the element to be searched\n");
                          scanf("%d",&keynum);
                          
// linear search 
                          for(i=0;i<num;i++)
                         {
                             if (keynum == array[i])
                              {
                                  found=1;
                                  break;
                              }
                         }
    if(found==1)
    
        printf("key is found at position  elementis %d",i);
    else 
         printf("key element is not found in array"); 
                         
  
}  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    
