#include<stdio.h>
void  primecheck(int);
int main()
{
            int n;
            printf("enter the number\n");
            scanf("%d",&n);
            primecheck(n);

}
      void primecheck(int n)
  {
    int flag=0,i;
    for(i=2;i<=n/2;i++)
    if(n%i==0)
    flag=1;
  if(flag==0)
      printf("prime number");
  else
      printf("not a prime number");


 }

