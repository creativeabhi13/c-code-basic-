/******************************************************************************
                    structure program 4
*******************************************************************************/
#include <stdio.h>

        struct class
        {
            int number;
            char name[20];
            float marks;
            
        };

    int main()
{
            int x;
            struct class student1={001,"abhi",87};
            struct class student2={002,"abhishek",100};
            struct class student3;
            student3=student2;
            x=((student3.number == student2.number) && (student3.marks == student2.marks))?1:0;
            if(x==1)
            {
                printf("\n student2 student3 are same \n");
                printf("%d %s %f\n",student3.number,student3.name,student3.marks);
              
            }
            else {
                printf("student2 and student3 are diffrent");
            }        
    
}

