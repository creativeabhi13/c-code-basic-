#include<stdio.h>
int main()
{
    printf("%d", printf("%s" , "HELLO WORLD"));
    return 0;
}