#include<stdio.h>
void example(void);
int main()
{
    
    int i;
    for(i=1;i<=3;i++)
    example ();
}
 void example (void)
 {
     static int x=0;
     x=x+1;
     printf("%d",x);
     
     
     
 }
    
    
    
    
