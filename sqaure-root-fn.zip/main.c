#include <stdio.h>
#include <math.h>
int main()
{
    int s,n;
    double d,x;
    
    printf("Enter the number\n");
    scanf("%d",&n);

 
if (n > 0){
    /* calculate decimal part of a number*/
    for (s=1 ; s*s<=n;s++);  
        s--;
        
    /* calculate fractional part of sqrt of n*/
    for (d=0.000001 ; d<=1.0; d+=0.000001){
        x=(double)s+d;
        if (x*x>n){
           x=x-0.000001; 
           break;
        }
    }                
                  
     printf("sqrt of %d=%lf\n",n,x);
     printf("sqrt using built-in func of %d=%lf",n,sqrt(n));
    
}
else printf( "invalid input");

    return 0;
}
