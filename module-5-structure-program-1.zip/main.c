/***********************************************************************************
                        structure program 1
 ***********************************************************************************/ 
#include<stdio.h>
struct personal
{
    char name[20];
    int day;
    char month[10];
    int year;
    float salary;
};
int main()
{
    struct personal person;
    printf("enter the value\n");
    printf("enter name,date of joining and salary\n");
    scanf("%s %d %s %d %f",
    person.name,
    &person.day,
    person.month,
    &person.year,
    &person.salary);
    printf("name,date of joining and salary \n");
    printf("%s %d %s %d %f",
    person.name,
    person.day,
    person.month,
    person.year,
    person.salary);
    
}    
    
    
    
    
    
    
    

