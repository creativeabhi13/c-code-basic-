/**************************************************************************
  program model q ppr 1 3-b
 
 Write a ‘C’ Program to check whether a given number is even or odd using if –else
statement. 
   **************************************************************************/
  #include<stdio.h>
  int main()
  {
      int n;
      printf("enter the  positive number\n");
      scanf("%d",&n);
      if(n % 2==0)
       printf("the even number is %d\n",n);
    else
        printf("the  odd number is%d\n",n);
      
      
      
      
  }