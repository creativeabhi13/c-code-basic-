/*****************************************************************************************
 
 model qppr-2 6-a
 Explain string manipulation library functions with their syntaxes. Write
a program to check whether a string is palindrome or not. 

 *******************************************************************************************/ 