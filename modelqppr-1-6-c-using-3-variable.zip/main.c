/*****************************************************************************
 model qppr-1 6-c
 Write a ‘C’ Program to concatenate two strings without using built in function
 ******************************************************************************/ 
 #include<stdio.h>

 int main()
 {
     char str1[50], str2[50], i,j;
     char str3[50];
     printf("enter the first string\n");
     scanf("%s",str1);
     
     printf("enter the second string\n");
     scanf("%s",str2);
     for(i=0; str1[i]!='\0';++i)
     str3[i]=str1[i];
     
      for(j=0; str2[j]!='\0';++j,++i)
        {
            str3[i]=str2[j];
           
        }
     
     printf("\noutput %s",str3);
     

     
     
 }