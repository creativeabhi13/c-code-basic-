// nested for loop using grade or fiesrt secnd division criteria
#include<stdio.h>
#define FIRST 360
#define SECOND 240
int main()
{
int n,m,i,j,roll_number,marks,total;
printf("enetr number of student and subject\n");
scanf("%d%d",&n,&m);


for(i = 1; i<=n; i++)
{
	printf("Enter roll_number :\n");
	scanf("%d", &roll_number);
	total = 0;
        printf("\n Enter marks of %d subjects for Roll No %d\n", m, roll_number);
	for(j=1; j<=m; j++)
	{
		scanf("%d", &marks);
		total = total + marks;
	}
	printf("Total Marks = %d", total);
	if (total >= FIRST)
		printf("First Division");
	else if (total >= SECOND)
		printf("\nSecond Division");
	else
		printf("\n*****Fail*******");
}






}
