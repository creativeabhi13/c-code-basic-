/*****************************************************************************************
 
 model qppr-2 6-b
 Write an algorithm and develop a C program to search an integer from
N numbers in ascending order using binary searching technique 
 
 *******************************************************************************************/ 
#include<stdio.h>
int main()
{
    int array[50],i,n,key,last,first,middle;
    printf("enter the number of element in array\n");
    scanf("%d",&n);
    printf("enter the %d element of array \n",n);
    for(i=0;i<n;i++)
     scanf("%d",&array[i]);
     printf("enter the search key\n");
     scanf("%d",&key);
     first=0;
     last=n-1;
     while(first<=last)
     {
         middle=(first+last)/2;
     
      if(array[middle]<key)
       {
           first=middle+1;
       }
     else if(array[middle]=key) {
     
         printf("key is found at location : %d \n",middle+1);
          break;
         
     }
     else {
          last=middle-1; 
          }
          if (first > last){
          printf("key is not found"); }

}
}
