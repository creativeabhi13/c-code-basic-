#include<stdio.h>
#define MAXGIRLS 4
#define MAXITEMS 3
main()
{
	int value[MAXGIRLS][MAXITEMS];//a[4][3]
	int girl_total[MAXGIRLS],item_total[MAXITEMS];
	int i,j,grand_total;

	printf("Enter values, one at a time, row wise\n\n");
	
	for(i=0;i<MAXGIRLS;i++)
	{
		girl_total[i]=0;
		for(j=0;j<MAXITEMS;j++)
		{
			scanf("%d",&value[i][j]);//365
			girl_total[i]+=value[i][j];//girl_total[0]=310+275+365=950;
		}
	}	


	for(j=0;j<MAXITEMS;j++)
	{
		item_total[j]=0;
		for(i=0;i<MAXGIRLS;i++)
		{
			item_total[j]+=value[i][j];
		}
	}

	grand_total=0;
		for(i=0;i<MAXGIRLS;i++)
		{
			grand_total+=girl_total[i];//0+950+725+880+940=3495
		}


printf("\nGIRLS TOTALS\n\n");
for(i=0;i<MAXGIRLS;i++)
	printf("Salesgirl[%d]=%d\n",i+1,girl_total[i]);

printf("\nITEM TOTALS\n\n");
for(j=0;j<MAXITEMS;j++)
		
	printf("Item[%d]=%d\n",j+1,item_total[j]);

printf("\nGrand Total=%d\n",grand_total);
		
}
