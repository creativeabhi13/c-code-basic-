/******************************************************************************
                        STRUCTURE PROGRAM 2(a)
*******************************************************************************/
#include <stdio.h>
int main()
{
   
      struct
        {
            int weight;
            float height;
        }
        student={60,180.5};
        printf("student weight student height \n");
        printf("%d\t\t%f",student.weight,student.height);
   
   
}   
   
   
   
   
   
   
    



