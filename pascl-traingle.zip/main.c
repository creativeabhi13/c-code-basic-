// pascal traingle
#include<stdio.h>
main() {
    int rows, coef=1, space, i, j;
    printf("Enter number of rows: ");
    scanf("%d", &rows); //4
    for (i=0; i<rows; i++) {
        
	for (space=1; space <= rows-i; space++)
            printf("  ");

        for (j=0; j<=i; j++) {
            if (j==0 || i==0)
                coef = 1;
            else
                coef=coef*(i-j+1)/j;

            printf("%4d", coef);
        }
        printf("\n");
    }
}



/*
 rows=4

i=0,1,2,3
======== 1st Iteration ========
i=0
space=1 space<= 4-0 space++
  space= 1     1<=4             --
  space= 2     2<=4             ----
  space= 3     3<=4             ------
  space= 4     4<=4             --------
  space= 5     5<=4 X           --------


j=0   j<=i  (0<=0) j++

if (j==0 || i==0)
   coef = 1;

                                 --------1

j=1 1<=0 X

(\n)

===========================
======== 2nd Iteration ========
i=1

space=1 space<= 4-1=3
  space= 1     1<=3             --
  space= 2     2<=3             ----
  space= 3     3<=3             ------
  space= 4     4<=3  X          ------

j=0   j<=1  (0<=1) j++

if (j==0 || i==0)
   coef = 1;                    --------1
                                ------1
j=1 (1<=1) 
if (j==0 || i==0) X

else

coef=coef*(i-j+1)/j;
coef=1*(1-1+1)/1;
coef=1*1 =1                    --------1
                               ------1----1
printf("%4d", coef)

j=2 (2<=1) X

============================
======== 3rd Iteration ========
i=2

space=1 space<= 4-2=2
  space= 1     1<=2             --
  space= 2     2<=2             ----
  space= 3     3<=2 X           ----



j=0   j<=2  (0<=2) j++

if (j==0 || i==0)
   coef = 1;                    --------1
                                ------1----1
j=1 (1<=2)                      ----1
if (j==0 || i==0) X

else

coef=coef*(i-j+1)/j;
coef=1*(2-1+1)/1;
coef=1*2 =2                    --------1
                               ------1----1
printf("%4d", coef)            ----1----2
j=2 (2<=2)

coef=coef*(i-j+1)/j;
coef=2*(2-2+1)/2;
    = 1

                               --------1
                               ------1----1
printf("%4d", coef)            ----1----2----1            
*/


/*
--------1
------1----1
----1----2----1
--1----3----3----1

*/
