/***************************************************************************
An electricity board charges the following rates for the use of electricity: 
for the first 200 units 80 paise per unit: for the next 100 units 90 paise per
unit: beyond 300 units Rs 1 per unit. All users are charged a minimum of Rs. 100
 as meter charge. If the total amount is more than Rs.400,
 then an additional surcharge of 15% of total amount is charged.
 Write a program to read the name of the user, number of units consumed
*****************************************************************************************************/
#include<stdio.h>
#define METERCHARGE 100
int main()
{
    char name[20];
    float totalcharge,units;
    printf("enter the name of the customer and units consumed");
    scanf("%s %f",&name,&units);
    if(units<=200)
      {
          totalcharge=(units*0.8)+METERCHARGE;
      }
 else if(units<=300)
    {
        totalcharge=160+(units-200)*0.9+METERCHARGE;
      }    
else if(units>300)
    {
        totalcharge=250+(units-300)+METERCHARGE;
    }
        if(totalcharge>400)
    {
        totalcharge=totalcharge+(totalcharge*0.15);
        
        
    }
    
    
    printf("name of the person= %s and total units consumed =%f",name,totalcharge);
    
}
