/*********************************************************************
 15. Implement Recursive functions for Binary to Decimal Conversion.
 lab prog 15
 
 **************************************************************/ 


#include<stdio.h>
#include<stdlib.h>
int iter=0, count=1;
int conBintoDec(long int num)
{
iter++;
if(iter!=1) count*=2;
if(!(num/10)) return num*count;
return ( (num%10)*count+conBintoDec(num/10));
}
int main()
{
long int dig;
int res;
 printf("Enter a binary number =");
scanf("%ld",&dig);
res= conBintoDec(dig);
printf("The decimal equivalent of a binary num %ld = %d",dig,res);
getchar();
}
