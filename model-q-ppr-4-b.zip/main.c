/******************************************************************************

model q ppr 1 4-b
 Explain the syntax of nested ‘if...else’ statement. Write a ‘C’ Program to find largest of these
numbers using nested ‘if’ statement
*******************************************************************************/

#include<stdio.h>
int main()
{
    int a,b,c;
    printf("enter the numbers");
    scanf("%d%d%d",&a,&b,&c);
    if(a>b && a>c)
    {
        printf("a is largest" ,a);
    }    
else if(b>a && b>c)
   {
       printf("b is largest",b);
   }
    else 
    {
        printf("c is largest",c); 
    }   
    
}
