#include<stdio.h>
int main()
{
    int n,i,t1=0,t2=1,next;
          printf("enter the number");
          scanf("%d",&n);
          printf("fibonacii series:");
    for(i=1;i<=n;++i){
          printf("%d",t1);
          next=t1+t2;
          t1=t2;
          
    }






}

