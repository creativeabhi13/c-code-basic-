/******************************************************************************
model q ppr 1 5-c
Write a ‘C’ Program to check a number is prime or not? 

*******************************************************************************/

    
    
#include<stdio.h>
int main()
{

      int flag=0,n,i;
      printf("enter the number");
      scanf("%d",&n);
      for(i=2;i<=n/2;i++){
        if(n%i==0)
         flag=1;
       }
     if(flag==0)
          printf("the number is prime");
    else
      printf("the number is not prime");

}

    
    
    
    
    
    
    
    
    


