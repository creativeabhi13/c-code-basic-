/******************************************************************************
                        Lab Program 13
13. Implement structures to read, write, compute average- marks and the students
scoring above and below the average marks for a class of N students.                        
*******************************************************************************/
#include<stdio.h>
struct marks
{
            char name[30];
            int sub[3];
            float average;
};
main()
{
      struct marks student[10];     
      int i,j,n,count;
      float total,totalavg=0,classAvg;
      
      printf("Enter the number of students\n");
      scanf("%d", &n);
      for(i=0;i<n;i++)
       {
           printf("Enter the student %d details\n",i);
           printf("Enter Student name\n");
           scanf("%s", student[i].name);
           printf("Enter subject marks\n");
           for(j=0;j<=2;j++)
                scanf("%d", &student[i].sub[j]);
       }
                                            
    for (i = 0; i<n; i++)
    {
         total=0;
       for (j = 0; j<=2; j++)
       {
              total+= student[i].sub[j];   	 
       }
       student[i].average = total/3;
       totalavg+=student[i].average;
    } 
    classAvg=totalavg/n;
    
    printf("Class Average =%f\n",classAvg); 
    printf("\nStudent above class average\n");
    count=0;
    for(i=0;i<n;i++)
    {
        if(student[i].average>=classAvg)
        {
            printf("%s\n",student[i].name);
            count+=1;
        }
         
    }
    if (count==0)printf("nil");
    
   count=0;
   printf("\nStudent below class average\n");
   for(i=0;i<n;i++)
   {
      if(student[i].average<classAvg)
      {
         printf("%s\n",student[i].name);
         count+=1;
      }      
   }
   if (count==0)printf("nil");
    
}

//
/* sample output 1
Enter the number of students                                                                                                    
                                                                                                                                
2                                                                                                                               
Enter the student 0 details                                                                                                     
Enter Student name                                                                                                              
aadil                                                                                                                           
Enter subject marks                                                                                                             
45                                                                                                                              
23                                                                                                                              
45                                                                                                                              
Enter the student 1 details                                                                                                     
Enter Student name                                                                                                              
rahim                                                                                                                           
Enter subject marks                                                                                                             
89                                                                                                                              
78                                                                                                                              
76                                                                                                                              
Class Average =59.333336                                                                                                        
                                                                                                                                
Student above class average                                                                                                     
rahim                                                                                                                           
                    