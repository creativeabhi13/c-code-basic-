#include<stdio.h>
#define ROWS 5
#define COLUMNS 5
main()
{
	int row, column, product[ROWS][COLUMNS];
	int i, j;
	printf("\nMULTIPLICATION TABLE\n\n");
	printf("\n---------------------------------\n");
		for (j = 1; j <= COLUMNS; j++)
			printf("% 6d", j);
		printf("\n---------------------------------\n");
	for (i = 0; i < ROWS; i++)
	{
		row = i + 1;
		printf("%-3d|", row);//2|
		for (j = 1; j <= COLUMNS ; j++)
		{
			column = j;
			product[i][j] = row *column;
			printf("% -5d|",product[i][j]);
		}
	printf("\n");
	}
	printf("---------------------------------\n");
}
