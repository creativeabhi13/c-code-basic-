/***********************************************************************************
 * model ppr 1  q 4c
Write a ‘C’ Program to find the sum of odd numbers ‘n’ natural numbers using do ‘while’
                                loop. 6M
***********************************************************************************/



#include<stdio.h>
int main()
{
int counter = 0,sum=0,n;
printf("Enter the value of n");
scanf("%d",&n);
do{
    counter++; 
    if(counter % 2 != 0){
                printf("%d\n",counter);
                sum += counter;
                                    }
    } while (counter <= n);
    printf("Sum of odd number:=%d", sum);
}
