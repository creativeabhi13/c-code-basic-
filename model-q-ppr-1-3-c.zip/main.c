/*****************************************************************************
  
  model q ppr 1 3-c
  Write a ‘C’ Program to perform the simple calculator operations like addition, subtraction,
   multiplication & division use ‘switch’ statement in program. 
  
 ***************************************************************************/
 #include<stdio.h>
 int main()
 {
    float a,b;
    char op;
    printf("enter the value a op and b");
    scanf("%f%s%f",&a,&op,&b);
    switch(op)
    {
     case '+' : printf("the sum of a and b is %f",a+b);
     break;
      case '-': printf("the subtraction of a and b is %f",a-b);
     break;
      case '*' : printf("the product of a and b is %f",a*b);
     break;
      case '/' : printf("the division of a and b is %f",a/b);
     break;
     
     default :printf("invalid operator");
     
     
    }
 }