/****************************************************************************************
program 10 lab 
10. Write functions to implement string operations such as compare, concatenate,
string length. Convince the parameter passing techniques.



*************************************************************************************/
#include<stdio.h>
#include<stdlib.h>
void stringcompare(char str1[50], char str2[50]);
void stringconcatenate(char str1[50], char str2[50]);
int stringlength(char str1[50]);
int main()
{
	char str1[50],str2[50];
	int option,len;
	printf("1.string comparision\n 2. string concatenation\n 3. string length\n");
        scanf("%d", &option);
	switch(option)
	{
	case 1:printf("String comparision\n");
			
			printf("Enter the first string:\n");
			scanf("%s",str1); //jit
			printf("Enter the second string\n");
			scanf("%s",str2);//jit
			stringcompare(str1, str2);//("jit\0","jit\0")
		break;
	case 2:printf("String concatenation\n");
	
			printf("Enter the first string:\n");
			scanf("%s",str1);// jit
			printf("Enter the second string:\n");
			scanf("%s",str2);//bangalore
			printf("string concatenation\n");
			stringconcatenate(str1, str2);//("jit\0","bangalore\0" )
		break;
	case 3:printf("String length\n");
			
			printf("Enter the string\n");
			scanf("%s",str1);
			len=stringlength(str1);
			printf("The length of the string is %d:",len);
		break;
	default:printf("Invalid option");
	}
}

void stringcompare(char str1[], char str2[]){
int len1, len2, i;
len1=stringlength(str1);//("jit\0")//3
len2=stringlength(str2);//("jid\0")//3
if(len1!=len2)
	printf("Strings are different\n");
else
{
	for(i=0;str1[i]!='\0';i++)
	{
		if(str1[i]!=str2[i])  //i=2 t==d
		{
			printf("Strings are different\n");
			exit(0);
		}
        }
	printf("Strings are same\n");
}
}

void stringconcatenate(char str1[], char str2[]){
char str3[50];
int k,i;
k=0;
for(i=0;str1[i]!='\0';i++) // str1="jit\0" str2="bangalore\0"
{
	str3[i]=str1[i];   //i=3, str3[2]=str1[2], str3[2]=t k=3 str3="jitbangalore\0"
	k=k+1;
}
for(i=0;str2[i]!='\0';i++)//i=9, str3[11]=str2[8]; str3[11]=e    k=12  str3[12]=\0
{
	str3[k]=str2[i];
	k=k+1;
}
str3[k]='\0';
printf("Concatenated string is %s",str3);
}

int stringlength(char str1[]){ //jit\0
	int count=0,i;
	for(i=0;str1[i]!='\0';i++)	//i=3, str1[3]!=\0   \0!=\0
	{                               // count=2+1=3 //3
		count+=1;
	}
	return count;
}
// 
/*
sample ouput 1;                   
1.string comparision                                                                                                                                     
 2. string concatenation                                                                                                                                 
 3. string length                                                                                                                                        
1                                                                                                                                                        
String comparision                                                                                                                                       
Enter the first string:                                                                                                                                  
abhi                                                                                                                                                     
Enter the second string                                                                                                                                  
kr                                                                                                                                                       
Strings are different


1.string comparision                                                                                                                                     
 2. string concatenation                                                                                                                                 
 3. string length                                                                                                                                        
1                                                                                                                                                        
String comparision                                                                                                                                       
Enter the first string:                                                                                                                                  
abhi                                                                                                                                                     
Enter the second string                                                                                                                                  
abhi                                                                                                                                                     
Strings are same 
 sample output 2
 1.string comparision                                                                                                                                     
 2. string concatenation                                                                                                                                 
 3. string length                                                                                                                                        
2                                                                                                                                                        
String concatenation                                                                                                                                     
Enter the first string:                                                                                                                                  
abhishek                                                                                                                                                 
Enter the second string:                                                                                                                                 
kumar                                                                                                                                                    
string concatenation                                                                                                                                     
Concatenated string is abhishekkumar

sample ouput 3.
1.string comparision                                                                                                                                     
 2. string concatenation                                                                                                                                 
 3. string length                                                                                                                                        
3                                                                                                                                                        
String length                                                                                                                                            
Enter the string                                                                                                                                         
abhishekkumar                                                                                                                                            
The length of the string is 13:                                                                                                                          
                                   
 */
