/******************************************************************************

program for bubble sort algorithm 
Write an algorithm and develop a C program that reads N integer
numbers and arrange them in ascending order using bubble Sort. 
*******************************************************************************/

#include<stdio.h>
 int main()
 {
 int array[100],i,j,n,temp;
 printf("enter the n element \n");
 scanf("%d",&n);
 printf("enter the integer %d\n",n);
    for(i=0;i<n;i++){
     scanf("%d",&array[i]);
    }
            for(i=0;i<n-1;i++)
              {
                 for(j=0;j<n-i-1;j++)
                  {
                      if(array[j]>array[j+1])
                         {
                             temp=array[j];
                             array[j]=array[j+1];
                             array[j+1]=temp;
                         }
                   }
                 
              }
                                   printf("sorted list is in ascending order :\n");
                                    for(i=0;i<n;i++)
                                     printf("%d\n",array[i]);
}                                     
                                     
