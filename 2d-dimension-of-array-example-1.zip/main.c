#include<stdio.h>
#define MAXGIRLS 4
#define MAXITEMS 3
int main()
{
      int value[MAXGIRLS][MAXITEMS];
      int girl_total[MAXGIRLS],items_total[MAXITEMS];
      int i,j,grand_total;
      printf("entert the valuesvone at a time,row wise\n\n ");
         for(i=0;i<MAXGIRLS;i++)
        {
            girl_total[i]=0;
            for(j=0;j<MAXITEMS;j++)
              {
                scanf("%d",&value[i][j]);
                girl_total[i]+=value[i][j];
              }
        }

                     for(j=0;j<MAXITEMS;j++)
                      {
                         items_total[j]=0;
                          for(i=0;i<MAXGIRLS;i++)
                             {
                               items_total[j]+=value[i][j];
                             }
                      }
                                grand_total=0;
                                for(i=0;i<MAXGIRLS;i++)
                                {
                                  grand_total=girl_total[i];
                                }

                      printf("\ngirls total\n\n");
                      for(i=0;i<MAXGIRLS;i++)
                      printf("sales girls[%d]=[%d]\n",i+1,girl_total[i]);
                      printf("\n items total \n\n");
                      for(j=0;j<MAXITEMS;j++)
                      printf("items[%d]=[%d]\n",j+1,items_total[j]);
                      printf("\n grand total=%d\n",grand_total);
}
