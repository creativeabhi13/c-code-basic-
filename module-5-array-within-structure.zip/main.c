/**********************************************************************************************************************8**********************
                            PROGRAM 7 MODULE 5 (ARRAYS WITHIN STRUCTURE)
************************************************************************************************************************8**********/
#include <stdio.h>
struct marks
{
    int sub[3];
    int total;
    
};

int main()
{
  int i,j;
  struct marks student[3]={{45,68,81,0},{75,53,69,0},{57,36,71,0}};
  struct marks subject_total={0,0,0,0};
  for(i=0;i<=2;i++)
     {
        for(j=0;j<=2;j++){
            student[i].total+=student[i].sub[j];
            subject_total.sub[j]+=student[i].sub[j];
        }       
            subject_total.total+=student[i].total;
        }    
            
        printf("student total\n\n");
        for(i=0;i<=2;i++)
         {
             
             printf("student[%d] %d\n",i+1,student[i].total);
             
         }
         printf("subject total\n\n");
         for(j=0;j<=2;j++)
         {
             printf("subject[%d] %d\n\n",j+1,subject_total.sub[j]);
         }
     printf("\n grand total=%d\n",subject_total.total);    
}         
         
         
         
         
         

  
  
  
  
  
  
  
  
  
  
