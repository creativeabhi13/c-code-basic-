#include <stdio.h>
main()
{
   int m, n, r, c, first[10][10], second[10][10], sum[10][10];
 
   printf("Enter the number of rows and columns of matrix\n");
   scanf("%d%d", &m, &n);
   printf("Enter the elements of first matrix\n");
 
   for (r = 0; r < m; r++)
      for (c = 0; c < n; c++)
         scanf("%d", &first[r][c]);
 
   printf("Enter the elements of second matrix\n");
 
   for (r = 0; r < m; r++)
      for (c = 0 ; c < n; c++)
         scanf("%d", &second[r][c]);
   
   printf("Sum of entered matrices:-\n");
   
   for (r = 0; r < m; r++) {                          // first   second      sum
      for (c = 0 ; c < n; c++) {
         sum[r][c] = first[r][c] + second[r][c];     //    2 2     3 3        5 5 
         printf("%d\t", sum[r][c]);                 //     2 2     3 3        5 5
      }                                          //  r=2    c=2
      printf("\n");                     //sum[r][c] = first[r][c] + second[r][c];
   }                                    //sum[1][1] = first[1][1] + second[1][1];
}                                       //sum[1][1] =     2   +  3   = 5
