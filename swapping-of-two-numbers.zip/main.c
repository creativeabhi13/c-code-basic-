#include<stdio.h>
int main()
{
    
    int p,q,temp;
    printf("enter the wo number");
    scanf("%d %d",&p,&q);
    temp=p;
    p=q;
    q=temp;
printf("the swapping of two number p=%d and q= %d",p,q);
    
    
    
}