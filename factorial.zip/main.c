// program of a factorila of n

#include<stdio.h>
int main()
{

      int i,n,x=1;
      printf("enter the numbr n");
      scanf("%d",&n);
      for(i=n;i>=1;i--)
    {
     x*=i;

    }

  printf("the n!=%d\n",x);
}

