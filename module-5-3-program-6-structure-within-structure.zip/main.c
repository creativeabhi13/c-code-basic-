/*********************************************************************************************************
                                      structure program 6             
 ********************************************************************************************************/
 #include<stdio.h>
 
 struct marks
 {
        int sub1;
        int sub2;
        int sub3;
        int total;
        
 };
 int main()
 {
     
     int i;
     struct marks student[3]={{45,68,81,0},{75,53,69,0},{57,36,71,0}};
     struct marks subject_total={0,0,0,0};
      for(i=0;i<=2;i++)
      {
          
         student[i].total=student[i].sub1+student[i].sub2+student[i].sub3; 
          
          subject_total.sub1=subject_total.sub1+student[i].sub1 ;
          subject_total.sub2=subject_total.sub2+student[i].sub2 ;
          subject_total.sub3=subject_total.sub3+student[i].sub3 ;
          
          subject_total.total=subject_total.total+student[i].total ;
      }
      printf("STUDENT TOTAL\n\n");
      for(i=0;i<=2;i++)
      {
          printf("student[%d] %d\n",i+1,student[i].total);
      }    
         printf("\n subject total\n\n");
         printf("%s%d\n%s%d\n%s%d\n","subject 1",subject_total.sub1,
                                     "subject 2",subject_total.sub2,
                                     "subject 3",subject_total.sub3);
                                                                        
          printf("\n grand total=%d\n",subject_total.total);                                                              
}
          
          
          
          
          
          
      
     
     
     
 
