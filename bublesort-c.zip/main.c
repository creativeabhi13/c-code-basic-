#include<stdio.h>
int main()
{
    int array[100],i,n,j,temp;
    printf("enter the number of element\n",n);
    scanf("%d",&n);
    printf("enter the %d ineteger\n",n);
    for(i=0;i<n;i++)
    scanf("%d",&array[i]);
           for(i=0;i<n-1;i++)
        {
                    for(j=0;j<n-1;j++) 
            {
                
                if(array[j]>array[j+1])
                {
                 temp=array[j];
                 array[j]=array[j+1];
                 array[j+1]=temp;
                }    
            }   
                
        }   
    printf("sorted list in ascending order\n");
    for(i=0;i<n;i++)
    printf("%d\n",array[i]);
    
}
