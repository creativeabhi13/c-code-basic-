/*****************************************************************************
 model qppr-1 6-c
 Write a ‘C’ Program to concatenate two strings without using built in function
 ******************************************************************************/ 
 #include<stdio.h>
 #include<string.h>
 

 int main()
 {
     char str1[50], str2[50];
     
     printf("enter the first string\n");
     scanf("%s",str1);
     
     printf("enter the second string\n");
     scanf("%s",str2);
     strcat(str1,str2);
     printf("\noutput %s",str1);
     

     
     
 }
