#include <stdio.h>
 
int main()
{
  int m, n, p, q, i, j, k;
  int A[10][10], B[10][10], Res[10][10];
 
  printf("Enter number of rows and columns of first matrix\n");
  scanf("%d%d", &m, &n);
  printf("Enter number of rows and columns of second matrix\n");
  scanf("%d%d", &p, &q);
  
 if (n != p)  //3X3 3X3 ==3X3
    printf("The matrices can't be multiplied with each other.\n"); 
  else
  {
printf("Enter elements of first matrix\n");
 for (i = 0; i < m; i++)
    for (j = 0; j < n; j++)
      scanf("%d", &A[i][j]);
    
printf("Enter elements of second matrix\n");
 
    for (i = 0; i < p; i++)
      for (j = 0; j < q; j++)
        scanf("%d", &B[i][j]);
 
    for (i = 0; i < m; i++) {
      for (j = 0; j < q; j++) {             // A= mXn   B = pXq  res=mXq
                                              // 1 1          1 1     2 2
	Res[i][j]=0;                           //1 1          1 1     2 2
        for (k = 0; k < p; k++) {
          Res[i][j]+= A[i][k]*B[k][j];//i=2,j=2,k=2 Res[1][1]=Res[i][j]+A[i][k]*B[k][j]
        }                                            //   = 1+A[1][1]*B[1][1]
      }                                              //    =1+1*1
                                                    //       =2
    }
 
    printf("Product of the matrices:\n");
 
    for (i = 0; i < m; i++) {
      for (j = 0; j < q; j++)
        printf("%d\t", Res[i][j]);
 
      printf("\n");
    }
  }
 }
