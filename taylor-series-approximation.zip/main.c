/******************************************************************************
                                 program 9
                         Taylor series approximation for sin(x)

*******************************************************************************/

#include <stdio.h>
#include<math.h>
int main()
{
    int degree,i;
    double numerator,denominator,term,sum,x;
    
    printf("Enter the degree\n");
    scanf("%d",&degree);

    x= degree*3.142/180;
    numerator =x;
    denominator =1; 
    i=2; 

do{
    term = numerator/ denominator;
    numerator= -numerator*x*x;
    denominator = denominator *i*(i+1);
    sum = sum + term; i=i+2;
}
while(fabs(term)>0.00001);
printf("sin(%d) without builtin function = %lf\n", degree,sum);
printf("sin(%d) using builtin function = %lf\n", degree,sin(x));
    return 0;
}


