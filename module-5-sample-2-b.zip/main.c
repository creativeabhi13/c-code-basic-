/******************************************************************************
                    structure program 2(b)
*******************************************************************************/
#include <stdio.h>

int main()
{
       struct 
            {
                int weight;
                float height;
                
            }
            student;
            scanf("%d %f",&student.weight,&student.height);
            printf("student weight student height\n");
            printf("%d\t\t %f",student.weight,student.height);
    
    
}

