// multiplication table
#include<stdio.h>
#define COLMAX 10
#define ROWMAX 12
int main()
{
    int row,column,y;
    row =1;
    printf("multiplication table \n");
    printf("...................................\n");
      do
        {
          column=1;
                do {
                   y=column*row;
                   printf("\n%d",y);
                   column=column+1;
                 }


             while ( column <= COLMAX);
         	   printf("\n");
	           row = row + 1;
	   }
       while (row  <= ROWMAX);
        printf("\n-------------------\n");
}

