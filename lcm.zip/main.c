#include<stdio.h>
int calculate(int a,int b);
int main()
{
    int c=3;
    int d=6;
    int e=calculate(c,d);

    printf("%d",e);
}
int calculate(int a, int b)
{
    static int m=0;
    m+= b;
    if((m % a == 0) && (m % b == 0))
    {
        return m;
    }
else

    calculate (a,b);



}
