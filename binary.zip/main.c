/******************************************************************************
                                 program 15
                         Resursive function to convert binary to 
                         // input :BinaryNumber.
                        // output :Decimal equivalent of BinaryNumber.

*******************************************************************************/
#include<stdio.h>
long int BinaryToDecimal (long int);
int main()
{
   long int bN,decNo;
   printf("Enter the Binary number(0 and 1s)");
   scanf("%ld",&bN);
printf("Decimal Equ of Binary number %ld= %ld",bN,BinaryToDecimal(bN)); 
}

long int BinaryToDecimal (long int BinaryNumber)
{
 if (!(BinaryNumber/10)) 
       return  (BinaryNumber);
else 
       return (BinaryNumber%10+BinaryToDecimal(BinaryNumber/10)*2); 
}