#include<stdio.h>
int main()
{
    
    int array[100],search,i,n;
    printf("enter the number of elements\n");
    scanf("%d",&n);
    printf("enter %d integers\n");
    for(i=0;i<n;i++)
    scanf("%d",&array[i]);
    printf("enter a number of search\n");
    scanf("%d",&search);
    for(i=0;i<n;i++) 
                    {
                    if(array[i]=search){
                        printf("%d is present at location %d\n",search,i+1);
                        break;
                    }
   
                  }
               if(i==n)
               printf("%d isn't present in the array.\n",search);    
    
}    
    
    
    
    
    
    
    
    